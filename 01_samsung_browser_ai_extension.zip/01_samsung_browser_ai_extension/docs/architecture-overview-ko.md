# Web-Agent Extension 아키텍처 및 비즈니스 로직 개요

## 1. 분석 대상
- 대상: MV3 기반 브라우저 확장 `web-agent`
- 핵심 엔트리:
  - `manifest.json`
  - `background.js`
  - `content.js`
  - `events.js`
  - `offscreen.js`
  - `overlay.js` / `overlay.html`
  - `google_docs_cs.js` / `google_docs_web.js`
  - `pdf_worker.js`

## 2. 한 줄 요약
이 확장은 외부 웹앱이 브라우저 내부 권한을 위임받아 탭, 히스토리, 스크린샷, 페이지 콘텐츠, 선택 텍스트, 오버레이, 에이전트 태스크를 제어할 수 있게 해 주는 브라우저 권한 게이트웨이이다.

## 3. 권한 및 신뢰 경계

### 3.1 Manifest 관찰 결과
- `permissions`
  - `activeTab`
  - `debugger`
  - `history`
  - `offscreen`
  - `scripting`
  - `tabs`
  - `cookies`
  - `declarativeNetRequestWithHostAccess`
  - `storage`
  - `sessions`
  - `tabGroups`
- `host_permissions`
  - `<all_urls>`
- `externally_connectable.matches`
  - `https://browser.samsung.com/*`
  - `https://stg.browser.samsung.com/*`
  - `https://dev.browser.samsung.com/*`
  - `*://localhost:*/*`

### 3.2 보안적으로 중요한 의미
- 외부 웹앱은 확장 프로그램에 직접 메시지를 보낼 수 있다.
- 확장 프로그램은 모든 URL에 대한 콘텐츠 스크립트/콘텐츠 수집 권한을 갖는다.
- `debugger`, `tabs`, `history`, `sessions`, `cookies` 조합은 매우 넓은 데이터 접근면을 만든다.
- `localhost` 허용은 개발 편의 기능일 수 있으나, 배포 빌드에 남아 있으면 강한 공격면이 된다.

## 4. 구성요소별 역할

| 구성요소 | 역할 | 핵심 데이터 |
| --- | --- | --- |
| `background.js` | 서비스 워커. 외부 메시지 게이트웨이, 툴 디스패처, 에이전트 실행 오케스트레이터 | 외부 요청, 탭/윈도우 상태, 스크린샷, 페이지 콘텐츠, 전역 상태 |
| `content.js` | 웹페이지 내 오버레이/선택영역/스크린샷 보조 | 선택 텍스트, 선택 HTML, 부분 스크린샷 |
| `events.js` | 페이지 입력 차단 및 작업 중 UX 통제 | 마우스/키보드 이벤트 |
| `offscreen.js` | HTML/PDF/Google Docs/Sheets를 Markdown 또는 텍스트로 변환 | DOM, 폼 값, 링크/라벨/타이틀, PDF 내용 |
| `overlay.js` | 에이전트 동작 상태 표시 UI | 상태 문자열, stop 동작 |
| `google_docs_cs.js` | Google Docs 페이지 월드 브리지 삽입 | injected script |
| `google_docs_web.js` | Google Docs 내부 호환성 스크립트 | page-world `eval` sink |
| `pdf_worker.js` | PDF 파싱 보조 워커 | PDF 텍스트 |

## 5. 비즈니스 로직 흐름

### 5.1 외부 웹앱 -> 확장 -> 브라우저 권한
1. 외부 웹앱이 `chrome.runtime.sendMessage(extensionId, payload)`로 확장에 메시지를 보낸다.
2. `background.js`의 외부 메시지 리스너가 메시지를 수신한다.
3. 요청이 `CALL_TOOL` 또는 `S_CALL_TOOL`이면 `jr()` -> `class ji` 메서드로 라우팅된다.
4. 해당 메서드는 `tabs`, `history`, `sessions`, `scripting`, `offscreen`, `captureVisibleTab` 등을 사용해 브라우저 작업을 수행한다.
5. 결과는 외부 웹앱 또는 sidecar 포트로 다시 전달된다.

### 5.2 에이전트 태스크 실행
1. 외부 웹앱이 `START_AGENT`를 보낸다.
2. `Br()`가 태스크 컨텍스트, 소켓, 탭 관리자, 브라우저 툴 관리자, 오버레이 관리자를 묶어 실행 객체를 만든다.
3. `Fi.startTask()`가 초기 탭 컨텍스트와 스크린샷을 수집하고 백엔드 에이전트 세션을 시작한다.
4. 이후 RPC 요청이 들어오면 브라우저 조작/콘텐츠 수집이 반복된다.

### 5.3 페이지 콘텐츠 수집
1. `GetContent`, `GetSidecarContext`, `GetSidecarPageContent` 계열 메서드가 탭을 기준으로 콘텐츠 수집을 시작한다.
2. 필요 시 숨은 탭을 띄워 읽고, `scripting.executeScript`, `debugger`, DOM snapshot 계열 경로를 사용해 HTML/메타를 가져온다.
3. `wt()`가 Google Docs/Sheets/PDF/HTML 분기 후 `offscreen.js`를 통해 Markdown 변환을 수행한다.
4. 결과는 `markdown`, `og_meta`, `pdp_data`, 메타데이터 구조로 외부에 반환된다.

### 5.4 선택영역/스크린샷 수집
1. `content.js`가 사용자의 선택영역을 감시한다.
2. 선택이 발생하면 `text`, `html`, `url`, `timestamp`를 `USER_SELECTION_CAPTURED`로 백그라운드에 보낸다.
3. 백그라운드는 이를 sidecar/voice/inline assistant 포트로 전달한다.
4. 스크린샷 기능은 전체/가시 영역/부분 캡처를 수행하고 결과를 포트로 재전달한다.

## 6. 내부 데이터 자산 흐름

| 자산 | 생성 위치 | 전달 경로 | 최종 소비자 | 보안 의미 |
| --- | --- | --- | --- | --- |
| 열린 탭 목록 | `chrome.tabs.query` | `S_GET_OPEN_TABS`, `SearchBrowser` | 외부 웹앱 | 브라우징 패턴 유출 |
| 현재 탭 정보 | `chrome.tabs.query({ active: true })` | `S_GET_CURRENT_TAB_INFO` | 외부 웹앱 | 현재 활동 탭 유출 |
| 스크린샷 | `captureVisibleTab`, `S_CAPTURE_TAB` | 외부 웹앱 또는 sidecar 포트 | 외부 웹앱 / 에이전트 | 화면 콘텐츠 유출 |
| 선택 텍스트/HTML | `content.js` | `USER_SELECTION_CAPTURED` | sidecar 포트 | 민감 텍스트 유출, HTML carrier |
| 페이지 Markdown | `GetContent`, `GetSidecarContext` | `CALL_TOOL` | 외부 웹앱 / 에이전트 | 페이지 전체 문맥 유출 |
| 히스토리 / 최근 닫은 탭 | `chrome.history`, `chrome.sessions` | `SearchBrowser` | 외부 웹앱 | 사용자 활동 이력 유출 |
| 저장된 prompt | 전역 변수 `cs` | `S_GET_USER_PROMPT` | 외부 웹앱 | 프롬프트 내용 유출 |
| 자동 응답 대상 탭 ID | 전역 변수 `ds` | `S_SET_AUTO_RESPONSE` | 임의 탭 | 응답 인젝션 / 상태 오염 |

## 7. 공격면 관점 정리
- 외부 origin 노출면
  - `chrome.runtime.onMessageExternal.addListener((s,e,t)=>(Tt(Ji)(s,e,t),!0))`
  - 별도 `chrome.runtime.onMessageExternal.addListener(async(s,e,t)=>{...})`
- 내부 런타임 메시지
  - `CAPTURE_*`
  - `USER_SELECTION_CAPTURED`
  - `OVERLAY_TASK_STOP`
- DOM / page-world / parser
  - `google_docs_web.js`의 `eval(...)`
  - `content.js`의 선택 HTML 직렬화
  - `offscreen.js`의 입력값/링크/라벨/타이틀 보존

## 8. 요약 결론
- 이 확장은 단순 UI 확장이 아니라 외부 웹앱에 브라우저 내부 권한을 대리 수행해 주는 권한 중개 레이어다.
- 따라서 취약점 평가는 일반 웹 확장 XSS만이 아니라, 외부 메시지 인증, 내부 정보 유출, 권한 남용, 전역 상태 오염, AI prompt/tool injection을 같은 비중으로 다뤄야 한다.
