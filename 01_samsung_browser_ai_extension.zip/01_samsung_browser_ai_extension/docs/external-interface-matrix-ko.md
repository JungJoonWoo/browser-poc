# External Interface Matrix

## 1. 외부 게이트웨이 구분

### Gateway A: 1차 외부 RPC 리스너
- 코드 형태: `chrome.runtime.onMessageExternal.addListener((s,e,t)=>(Tt(Ji)(s,e,t),!0))`
- 특징:
  - `manifest.json`의 `externally_connectable`에만 의존한다.
  - 별도의 runtime origin 검증이 보이지 않는다.
  - `localhost`도 그대로 포함된다.

### Gateway B: 2차 legacy/보조 외부 리스너
- 코드 형태: `chrome.runtime.onMessageExternal.addListener(async(s,e,t)=>{ if(!aa(e.origin)) ... })`
- 특징:
  - `aa()`가 `browser.samsung.com`, `stg`, `dev`, `localhost`를 허용한다.
  - `localhost`는 host name만 맞으면 추가 제약 없이 허용된다.

## 2. 외부 메시지 매트릭스

| Gateway | Message Type | Origin Guard | Handler | 주요 기능 | 보안 영향 |
| --- | --- | --- | --- | --- | --- |
| A | `CALL_TOOL` | `externally_connectable`만 적용 | `Ji` -> `jr` -> `class ji` | 브라우저 툴 호출 | 가장 강한 권한 노출면 |
| A | `START_AGENT` | `externally_connectable`만 적용 | `Ji` -> `Br` | 에이전트 태스크 시작 | 브라우저 조작 자동화 시작점 |
| A | `CLEANUP_AGENT_TASKS` | `externally_connectable`만 적용 | `Ji` | 태스크 정리 / 중단 | 기존 세션 간섭 |
| A | `MAKE_TAB_ID_VISIBLE` | `externally_connectable`만 적용 | `Ji` | 숨은 탭 표시 및 이동 | 탭 상태 변경 |
| B | `S_OPEN_TAB` | `aa(origin)` | legacy external handler | 새 탭 열기 | 브라우저 상태 변경 |
| B | `S_GET_OPEN_TABS` | `aa(origin)` | legacy external handler | 모든 열린 탭 반환 | 내부 정보 유출 |
| B | `S_CAPTURE_TAB` | `aa(origin)` | legacy external handler | 화면 스냅샷 반환 | 화면 정보 유출 |
| B | `S_GET_USER_PROMPT` | `aa(origin)` | legacy external handler | 전역 prompt 반환 후 삭제 | 프롬프트 유출 |
| B | `S_SET_AUTO_RESPONSE` | `aa(origin)` | legacy external handler | 저장된 탭으로 응답 주입 | 상태 오염 / 로직 하이재킹 |
| B | `S_CALL_TOOL` | `aa(origin)` + `!mobile` | legacy external handler -> `jr` | 브라우저 툴 호출 | 권한 노출면 |
| B | `S_GET_CURRENT_TAB_INFO` | `aa(origin)` | legacy external handler | 현재 활성 탭 정보 반환 | 내부 정보 유출 |
| B | `S_OPEN_PAGE_CURRENT_TAB` | `aa(origin)` | legacy external handler | 현재 탭 URL 변경 | 네비게이션 강제 |

## 3. 관찰된 `CALL_TOOL` 메서드 집합

아래 메서드는 `class ji`에서 직접 확인된 고신뢰 메서드다.

| Method | 기능 | 주요 입력 | 주요 출력 | 보안 의미 |
| --- | --- | --- | --- | --- |
| `GetContent` | URL 목록 콘텐츠 수집 | `pages`, `filter`, `request_id`, `key` | `contents[]` | 페이지 내용 대량 수집 |
| `GetSidecarContext` | 현재 탭 기준 컨텍스트 수집 | `request_id`, `key` | 현재 탭 콘텐츠 | 현재 화면 문맥 추출 |
| `SearchBrowser` | 히스토리/열린 탭/최근 닫은 탭 검색 | `queries`, `sources`, 시간 필터 | 검색 결과 | 브라우징 이력 유출 |
| `GetVisibleTabScreenshot` | 현재 가시 탭 캡처 | `format`, `quality` | `data_url` | 화면 유출 |
| `OpenTab` | 새 탭 열기 또는 기존 탭 이동 | `url`, `tab_id` | `tab` | 브라우저 제어 |
| `CloseTabs` | 탭 닫기 | `tab_ids[]` | 닫힌 탭 목록 | 상태 변경 |
| `GroupTabs` | 탭 그룹화 | `tab_ids[]`, `group_id`, `title`, `color` | 그룹 정보 | 상태 변경 |
| `UngroupTabs` | 그룹 해제 | `tab_ids[]`, `group_ids[]` | 해제 결과 | 상태 변경 |
| `SearchTabGroups` | 그룹 검색 | `queries[]` | 그룹 목록 | 탭 구조 유출 |
| `GetSidecarPageContent` | 특정 탭/URL 콘텐츠 추출 | `id`, `url` | `content`, `metadata` | 탭 내용 유출 |

## 4. 요청 형식 정규화

### 4.1 `CALL_TOOL`
```json
{
  "type": "CALL_TOOL",
  "method": "GetSidecarContext",
  "request": {
    "request_id": "wa-003-poc",
    "key": "wa-003-poc"
  }
}
```

### 4.2 `S_CALL_TOOL`
```json
{
  "type": "S_CALL_TOOL",
  "method": "SearchBrowser",
  "request": {
    "request_id": "wa-001-poc",
    "key": "wa-001-poc",
    "queries": [""],
    "sources": ["OPEN_TABS"]
  }
}
```

## 5. 보안상 핵심 메모
- Gateway A는 runtime origin 재검증이 없어 manifest 설정 실수의 영향을 그대로 받는다.
- Gateway B도 `localhost`를 명시적으로 신뢰한다.
- 두 게이트웨이 모두 데이터 조회와 브라우저 제어를 동시에 제공한다.
- 따라서 취약점은 개별 메시지 하나보다 "신뢰되지 않은 외부 페이지가 브라우저 권한 API를 호출할 수 있는 구조" 전체로 봐야 한다.
