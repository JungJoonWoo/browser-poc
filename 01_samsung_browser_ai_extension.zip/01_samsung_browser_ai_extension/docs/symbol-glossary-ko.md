# background.js 주요 심볼 의미 사전

아래 표는 난독화/번들링된 `background.js`를 문서화하기 위해 의미를 재구성한 것이다.

| 심볼 | 의미 | 근거 |
| --- | --- | --- |
| `aa` | legacy 외부 origin 허용 함수 | `hostname === "localhost"` 또는 Samsung 브라우저 도메인 허용 |
| `Ji` | 1차 외부 RPC 핸들러 | `CALL_TOOL`, `START_AGENT`, `CLEANUP_AGENT_TASKS`, `MAKE_TAB_ID_VISIBLE` 분기 |
| `jr` | 툴 호출 디스패처 | `new ji(...)[method](request)` 호출 |
| `ji` | 브라우저 권한 툴 서비스 클래스 | `GetContent`, `GetSidecarContext`, `SearchBrowser`, `OpenTab` 등 보유 |
| `Bi` | 내부 runtime 메시지 핸들러 | `CAPTURE_*`, `USER_SELECTION_CAPTURED`, `OVERLAY_TASK_STOP` 처리 |
| `Br` | 에이전트 태스크 부트스트랩 | socket, overlay, tab manager, browser tools 묶어 `Fi` 생성 |
| `Fi` | 실행 중 에이전트 태스크 객체 | task lifecycle, cleanup, reconnect, initial screenshot |
| `Le` | offscreen 프록시 | `OFFSCREEN_REQUEST`/`OFFSCREEN_RESPONSE`로 `offscreen.js` 메서드 호출 |
| `wt` | 콘텐츠 -> Markdown 파서 오케스트레이터 | HTML / PDF / Google Docs / Sheets 분기 |
| `tr` | 페이지 제한 검사 래퍼 | paywall/noindex/google search mobile 조건 차단 |
| `Vi` | 현재 탭 메타 수집 함수 | PDF 여부, `og:*` 메타 수집 |
| `Hi` / `st` | 열린 탭 캐시 서비스 | 창별 탭 캐시와 검색 |
| `Gi` / `Zs` | 브라우저 검색 서비스 | history / open tabs / recently closed 검색 |
| `X` | 외부 포트 맵 | sidecar/voice/inline assistant 연결 포트 저장 |
| `Oe` | 실행 중 task 맵 | `taskId` -> `Fi` 객체 |
| `cs` | 전역 user prompt 저장소 | `S_SET_USER_PROMPT`로 저장, `S_GET_USER_PROMPT`로 반환 후 삭제 |
| `ds` | 자동 응답 대상 탭 ID | `S_SET_USER_PROMPT` 수신 탭 기준 저장 |
| `Kr` | PDF viewer URL normalizer | `chrome-extension://` PDF viewer URL을 원본 URL로 변환 |
| `qe` | 탭 모델 정규화 함수 | 외부 응답용 `tab_id`, `url`, `title` 구조화 |

## 빠른 읽기용 구조도
- 외부 메시지 입구
  - `Ji`
  - legacy `onMessageExternal`
- 내부 브라우저 작업
  - `jr`
  - `ji`
  - `Bi`
- 에이전트 실행
  - `Br`
  - `Fi`
- 콘텐츠 수집 및 파싱
  - `Le`
  - `wt`
  - `Vi`
- 상태/캐시
  - `X`
  - `Oe`
  - `cs`
  - `ds`

## 문서화 메모
- 이후 취약점 리포트에서는 minified symbol 자체보다 위 의미명을 우선 사용한다.
- 단, 코드 대조를 위해 본 사전에서 원래 심볼도 함께 유지한다.
