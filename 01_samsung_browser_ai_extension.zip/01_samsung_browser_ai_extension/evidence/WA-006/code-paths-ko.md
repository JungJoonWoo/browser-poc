# WA-006 코드 경로 증적

## 1. 공격자 지정 URL 입력
```js
async GetContent(e){
  ...
  const i=(e.pages??[]).map(async d=>{
    const p=d.url??"",
    ...
    const u=await zi(d,this.scopedLogger,this.sender);
    ...
  })
}
```

의미:
- 외부 origin이 `pages[].url`을 지정할 수 있다.

## 2. hidden tab 생성
```js
const zi=async(s,e,t)=>{
  const {id:r}=s,n=s.url??"";
  ...
  return {
    type:"HIDDEN",
    id:(await uo("tool-call",e,t.tab?.windowId??chrome.windows.WINDOW_ID_CURRENT,!0)).id,
    url:o
  }
}
```

의미:
- 요청 대상 탭이 없으면 hidden tab을 생성한다.

## 3. 실제 URL 로드
```js
const Xi=async(s,{id:e,url:t})=>{
  const r=tt({tabContext:s,config:{action:"GET_CONTENT",waitForFCP:!0,...}});
  await chrome.tabs.update(e,{url:t}),
  await r.wait()
}
```

의미:
- hidden tab에 공격자 지정 URL을 실제로 로드한다.

## 4. 콘텐츠 수집 및 반환
```js
const {html:S,meta:L,isPdf:P,...}=await Lr(f,{filter:r}),
      {markdown:H,type:A}=await wt({tab:b,html:S,isPdf:P,...});
return {
  ...d,
  title:E,
  html:"",
  markdown:H,
  og_meta:L,
  pdp_data:I
}
```

의미:
- raw HTML 전체는 현재 코드 경로상 외부 반환에서 비워 두는 경우가 많지만, normalized content/markdown은 반환된다.

## 5. 보안 해석
- 사용자 브라우저 세션/렌더링 컨텍스트로 임의 URL을 열고 결과를 읽는다.
- 고전적 CSRF보다 강한 browser-driven content proxy다.

## 6. 관련 파일
- `background.js`
- `reports/write-network-assessment-ko.md`
- `reports/xss-csrf-assessment-ko.md`
