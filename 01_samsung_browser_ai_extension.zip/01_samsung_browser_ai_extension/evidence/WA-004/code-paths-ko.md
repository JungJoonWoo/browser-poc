# WA-004 코드 경로 증적

## 1. 외부 `START_AGENT` 진입
```js
if(s.type==="START_AGENT"){
  const r=s;
  ...
  return Br({
    query:r.task??"",
    taskId:r.uuid??"",
    ...r,
    base_url:r.base_url??"",
    extra_headers:JSON.parse(r.extra_headers??"{}"),
    ...
  }, ...)
}
```

의미:
- 외부 origin이 넘긴 `base_url`과 `extra_headers`가 그대로 태스크 시작 로직에 들어간다.

## 2. 원격 세션 bootstrap
```js
s.enable_reconnect
  ? o=new xo({baseUrl:s.base_url,endpoint:"/agent",...})
  : o=new Ao(s.base_url,r);
```

의미:
- 태스크용 원격 종단점이 외부 입력 `base_url`에 의해 결정된다.

## 3. 초기 탭 컨텍스트 및 스크린샷 송신
```js
const c={
  start_agent:{
    task:this.deps.initialPayload.query,
    task_uuid:this.deps.initialPayload.taskId,
    ...
    tabs_context:r,
    extra_headers:e,
    current_tab_base64_image:o
  }
};
this.deps.socket.send({ message:c, ... })
```

의미:
- 초기 부트스트랩 시 탭 컨텍스트와 현재 탭 스크린샷이 원격 종단점으로 전송될 수 있다.

## 4. 보안 해석
- localhost 악성 페이지가 extension 자체를 공격자 backend와 통신하게 만들 수 있다.
- 이건 단순 read->upload보다 더 강한 primitive다.

## 5. 관련 파일
- `background.js`
- `reports/write-network-assessment-ko.md`
- `poc/WA-004/start-agent-backend-hijack.html`
- `poc/WA-004/cloudflare-agent-endpoint.js`
