# 실제 PoC 수행 결과 반영 메모

## WA-001
- 성공:
  - 열린 탭 조회
  - 현재 활성 탭 조회
  - 페이지 이동
- 실패:
  - `CALL_TOOL:GetVisibleTabScreenshot`
- 해석:
  - 현재 설치본에서는 표준 `captureVisibleTab` 기반 CALL_TOOL 경로가 불안정할 수 있다.
  - legacy `S_CAPTURE_TAB`를 우선 PoC 경로로 사용해야 한다.

## WA-002
- 관찰 결과:
  - `S_GET_USER_PROMPT`는 `{ success: true, response: {} }`
  - `S_SET_AUTO_RESPONSE`는 `{ success: true }`
- 해석:
  - 외부 read/write endpoint는 응답한다.
  - 그러나 현재 세션에서 `cs`, `ds`가 세팅되지 않은 상태다.
  - 따라서 현재 설치본 기준 즉시 exploit보다는 조건부/잠복 인터페이스로 보는 것이 정확하다.
  - 현재 저장소 기준 `S_SET_AUTO_RESPONSE`는 write primitive이며, LLM 응답을 읽어 오는 direct exfil 경로는 확인되지 않았다.

## WA-003
- 관찰 결과:
  - `CALL_TOOL:GetSidecarContext` 성공
  - `markdown`에 아래 값 포함:
    - `WA003_FORM_SECRET_VALUE`
    - `WA003_TEXTAREA_SECRET`
  - 아래 마커는 현재 설치본 최신 실행에서 포함되지 않음:
    - `WA003_VISIBLE_TEXT`
    - `WA003_HIDDEN_ARIA_PROMPT`
    - `WA003_LINK_TITLE`
- 해석:
  - 현재 설치본에서 최소한 폼 값과 textarea 값이 실제 agent context에 유입됨이 입증되었다.
  - hidden aria / link-title / 일반 visible marker 계열은 parser 또는 렌더 경로 차이로 이번 실행에서 재현되지 않았다.
