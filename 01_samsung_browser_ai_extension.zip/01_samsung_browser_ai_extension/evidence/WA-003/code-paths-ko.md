# WA-003 코드 경로 증적

## 1. 선택 HTML 직렬화
```js
function i(c){
  try{
    const l=c.getRangeAt(0),a=document.createElement("div"),h=l.cloneContents();
    return a.appendChild(h),{
      text:c.toString().trim(),
      html:a.innerHTML,
      url:window.location.href,
      timestamp:Date.now()
    }
  }catch{return null}
}
```

의미:
- 공격자 제어 DOM 조각이 HTML 형태로 별도 보존된다.

## 2. 선택 데이터 전송
```js
chrome.runtime.sendMessage({
  type:"USER_SELECTION_CAPTURED",
  payload:{selection:l}
})
```

## 3. 입력값/폼 요소 보존
```js
const se=e=>{
  e.keep(["input","textarea","select","option"])
}
```

의미:
- 폼 값이 Markdown 변환 과정에서 제거되지 않고 보존된다.

## 4. `outerHTML` 보존 규칙
```js
focusedInput: {
  replacement:(t,r)=>r.outerHTML
}
```

## 5. Google Docs 모델 데이터 파싱
```js
const s=/DOCS_modelChunk\\s*=\\s*(\\[[\\s\\S]*?\\]);/,
o=i.body.innerHTML.match(s);
if(o?.[1]){
  const c=JSON.parse(o[1]).find(f=>f&&typeof f=="object"&&f.s);
  if(c?.s)return a(c.s)
}
```

의미:
- 숨은 모델 데이터 블록까지 텍스트로 추출한다.

## 6. sidecar 포트 전달
```js
d.forEach(l=>{
  l&&l.postMessage({
    type:"USER_SELECTION_CAPTURED",
    payload:{selection:a}
  })
})
```

## 7. 보안 해석
- 페이지 유래 텍스트/HTML/폼값/숨은 지시문이 agent context로 이동한다.
- 신뢰도 태깅, 필드 단위 차단, HTML sanitize가 보이지 않는다.

## 8. PoC 연결
- `poc/WA-003/prompt-injection-carrier-harness.html`
- `evidence/WA-003/raw-messages.json`
