# WA-002 코드 경로 증적

## 1. 전역 상태 저장
```js
let cs,ds;
chrome.runtime.onMessage.addListener(async(s,e,t)=>{
  s.type==="S_SET_USER_PROMPT"&&(cs=s.prompt,e.tab?.id!=null&&(ds=e.tab.id))
});
```

의미:
- `prompt`와 대상 탭 ID가 전역 변수에 저장된다.
- origin, requester, task, session binding이 없다.

## 2. 외부 prompt 읽기
```js
else if(r==="S_GET_USER_PROMPT"){
  const n=cs;
  return cs=void 0,t({success:!0,response:{prompt:n}})
}
```

의미:
- 허용 외부 origin은 현재 저장된 prompt를 읽을 수 있다.
- 읽기 후 삭제되므로 race condition성 탈취도 가능하다.

## 3. 외부 자동응답 주입
```js
if(r==="S_SET_AUTO_RESPONSE")
  return ds
    ? chrome.tabs.sendMessage(ds,{type:"S_AUTO_RESPONSE",response:s.response})
    : console.log("No automation tab ID"),
  t({success:!0});
```

의미:
- 허용 외부 origin은 저장된 탭에 임의 응답을 주입할 수 있다.
- 메시지 송신자와 원래 상태 생성자가 동일한지 확인하지 않는다.

## 4. 보안 해석
- 전역 prompt 탈취
- 다른 탭으로의 응답 인젝션
- 사용자 의도와 무관한 워크플로우 조작

## 5. PoC 연결
- `poc/WA-002/state-hijack-harness.html`
- `evidence/WA-002/raw-messages.json`
