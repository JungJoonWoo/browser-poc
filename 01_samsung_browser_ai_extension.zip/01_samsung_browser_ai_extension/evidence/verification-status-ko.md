# 검증 상태 메모

## 완료
- 정적 코드 분석
- 외부 인터페이스 식별
- 아키텍처/비즈니스 로직 문서화
- PoC 하네스 작성
- 증적용 raw message 예시 작성
- 설치본 `ai_extensions.json`을 읽어 실제 extension ID를 `mdnblglgnmnipmchmdjhlbaaeeolmfli`로 반영
- 실제 브라우저 수행 결과를 반영해 PoC/보고서를 재보정
- `WA-004`, `WA-005`, `WA-006` 증적 문서와 raw request 예시 작성

## 미실행
- 실제 브라우저에서의 버튼 클릭 재현
- 실제 Samsung 서버 연동
- 실제 sidecar UI 소비자까지 포함한 downstream XSS 검증

## 이유
- 현재 Codex 실행 환경에서는 브라우저 UI와 설치된 확장을 직접 조작할 수 없었다.
- 대신 재현 가능한 `localhost` 기반 PoC 하네스를 생성했고, 각 취약점별 선행 조건과 예상 결과를 문서에 남겼다.
- 저장소의 `content.js` 상수 ID와 설치본 ID가 달라, PoC는 설치본 기준 ID를 사용하도록 수정했다.

## 사용자 제공 실제 수행 결과
- WA-001:
  - 탭 관련 정보 조회 및 페이지 이동은 성공
  - `CALL_TOOL:GetVisibleTabScreenshot`는 generic `Unhandled error`
- WA-002:
  - 인터페이스 응답은 오지만 `prompt` 상태가 비어 있음
  - 현재 설치본 기준 즉시 재현은 실패
- WA-003:
  - 숨은 aria 텍스트, 폼 값, textarea 값, 링크 메타가 실제 `markdown` 결과에 포함됨
