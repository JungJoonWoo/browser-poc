# WA-001 코드 경로 증적

## 1. Manifest 증적
```json
"externally_connectable": {
  "matches": [
    "https://browser.samsung.com/*",
    "https://stg.browser.samsung.com/*",
    "https://dev.browser.samsung.com/*",
    "*://localhost:*/*"
  ]
}
```

의미:
- `localhost`에서 로드된 외부 페이지가 확장 프로그램에 메시지를 보낼 수 있다.

## 2. 1차 외부 게이트웨이 증적
```js
chrome.runtime.onMessageExternal.addListener((s,e,t)=>(Tt(Ji)(s,e,t),!0));
```

의미:
- `Ji`로 바로 진입한다.
- 이 리스너 자체에는 별도 runtime origin 재검증이 보이지 않는다.

## 3. `Ji`가 제공하는 외부 기능
```js
if(s.type===as) return t(await jr(s,e));
if(s.type==="CLEANUP_AGENT_TASKS") ...
if(s.type==="START_AGENT") ...
if(s.type==="MAKE_TAB_ID_VISIBLE") ...
```

의미:
- 허용 origin은 `CALL_TOOL`, `START_AGENT`, `CLEANUP_AGENT_TASKS`, `MAKE_TAB_ID_VISIBLE`를 직접 호출할 수 있다.

## 4. 2차 외부 게이트웨이 증적
```js
aa=s=>{
  if(!s) return !1;
  let e;
  try { e=new URL(s) } catch { return !1 }
  const { hostname:t } = e;
  return t==="localhost" ? !0 : ia.includes(t)
}
```

의미:
- `localhost`가 명시적으로 신뢰된다.

## 5. Legacy 메시지 노출 증적
```js
if(r==="S_OPEN_TAB") ...
else if(r==="S_GET_OPEN_TABS") ...
else if(r==="S_CAPTURE_TAB") ...
else if(r==="S_GET_USER_PROMPT") ...
else if(r==="S_SET_AUTO_RESPONSE") ...
else if(r==="S_CALL_TOOL"&&!ra) ...
else if(r==="S_GET_CURRENT_TAB_INFO") ...
else if(r==="S_OPEN_PAGE_CURRENT_TAB") ...
```

## 6. 영향 요약
- 정보 조회:
  - 열린 탭
  - 현재 탭
  - 스크린샷
  - `CALL_TOOL` 결과
- 상태 변경:
  - 탭 열기
  - 현재 탭 이동
  - 태스크 시작/정리
  - 숨은 탭 표시

## 7. PoC 연결
- `poc/WA-001/localhost-api-harness.html`
- `poc/WA-001/exfil-demo.html`
- `poc/WA-001/cloudflare-worker-receiver.js`
- `evidence/WA-001/raw-messages.json`
