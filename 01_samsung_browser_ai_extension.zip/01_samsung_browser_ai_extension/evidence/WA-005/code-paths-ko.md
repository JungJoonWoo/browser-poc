# WA-005 코드 경로 증적

## 1. 외부 쓰기 primitive

### 현재 탭 이동
```js
else if(r==="S_OPEN_PAGE_CURRENT_TAB"){
  const o=(await chrome.tabs.query({active:!0,currentWindow:!0})).filter(a=>a.active),
        i=s.url;
  o.length>0&&chrome.tabs.update(o[0].id,{url:i})
}
```

### 새 탭 열기
```js
if(r==="S_OPEN_TAB"){
  const n=s.url,
        o=await chrome.tabs.create({url:n,active:!0});
  return t({success:!0,response:{tab:o}})
}
```

### CALL_TOOL 기반 탭 상태 변경
```js
async OpenTab(e){ ... chrome.tabs.create(...) / chrome.tabs.update(...) }
async CloseTabs(e){ ... chrome.tabs.remove(i) ... }
async GroupTabs(e){ ... chrome.tabs.group(...) ... }
async UngroupTabs(e){ ... chrome.tabs.ungroup(...) ... }
```

### hidden tab reveal
```js
if(s.type==="MAKE_TAB_ID_VISIBLE"){
  ...
  await Ve(r,{muted:!1},{hidden:!1}),
  await chrome.tabs.move(r,{index:-1})
}
```

## 2. 보안 해석
- 외부 origin이 브라우저 상태를 직접 바꿀 수 있다.
- 피싱 리다이렉트, 작업 교란, 탭 숨김/노출 조작으로 이어질 수 있다.

## 3. 관련 파일
- `background.js`
- `reports/write-network-assessment-ko.md`
