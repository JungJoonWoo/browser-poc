# WA-004+ Write / Network / CSRF 관점 취약점 분석

## 요약
읽기 취약점 외에도, 현재 코드에는 외부 origin이 브라우저 상태를 바꾸는 write primitive와 extension 자체를 원격 종단점에 붙이는 network primitive가 존재한다. 시나리오상 가장 치명적인 것은 아래 두 개다.

| ID | 심각도 | 상태 | 분류 | 한 줄 요약 |
| --- | --- | --- | --- | --- |
| `WA-004` | Critical | Confirmed | Network / Exfiltration | `START_AGENT`가 공격자 제어 `base_url`을 받아 extension 자체가 공격자 backend로 탭 컨텍스트와 스크린샷을 송신할 수 있음 |
| `WA-005` | High | Confirmed | Write / Browser state manipulation | 외부 origin이 탭 열기/이동/닫기/그룹화/hidden tab reveal 등 브라우저 상태를 직접 바꿀 수 있음 |
| `WA-006` | Critical | Confirmed | CSRF-like / Browser-driven request proxy | `GetContent`가 hidden tab을 생성해 공격자 지정 URL을 사용자 세션으로 열고 콘텐츠를 수집할 수 있음 |

## WA-004: 공격자 제어 `base_url` 기반 원격 backend 송신

### 코드 관찰
- 외부 메시지 `START_AGENT`가 `Ji`를 통해 수신된다.
- 이때 외부 입력의 `base_url`과 `extra_headers`가 그대로 `Br(...)`로 전달된다.
- `Br(...)`는 소켓/세션 객체를 만들고, 태스크 시작 시 `tabs_context`와 `current_tab_base64_image`를 원격 종단점으로 보낼 수 있다.

### 시나리오
1. 사용자가 공격자 localhost 페이지를 연다.
2. 페이지가 `START_AGENT`를 호출하면서 `base_url`을 공격자 서버로 지정한다.
3. extension이 해당 서버와 에이전트 세션을 수립한다.
4. 현재 탭 컨텍스트, 스크린샷, 이후 브라우저 상호작용 데이터가 공격자 종단점으로 전송된다.

### 왜 Critical인가
- localhost 페이지가 읽은 뒤 업로드하는 수준이 아니라, extension 프로세스 자체가 공격자 backend와 통신하게 된다.
- 탭 컨텍스트 + 스크린샷 + agent task lifecycle 데이터가 한 번에 넘어갈 수 있다.
- 이후 remote agent orchestration까지 붙으면 브라우저 조작 확장성이 커진다.

### 보안 해석
- 이건 단순 정보 유출이 아니라 remote-control bootstrap 취약점에 가깝다.
- 현재 구조에서 `base_url`은 고신뢰 내부 상수처럼 취급돼야 하는데, 외부 origin이 제어한다.

### PoC
- 트리거 페이지: `poc/WA-004/start-agent-backend-hijack.html`
- Cloudflare receiver: `poc/WA-004/cloudflare-agent-endpoint.js`

## WA-005: 외부 origin의 브라우저 상태 변경(write primitive)

### 코드 관찰
외부 origin이 다음 동작을 직접 요청할 수 있다.
- `S_OPEN_TAB`
- `S_OPEN_PAGE_CURRENT_TAB`
- `CALL_TOOL/OpenTab`
- `CALL_TOOL/CloseTabs`
- `CALL_TOOL/GroupTabs`
- `CALL_TOOL/UngroupTabs`
- `MAKE_TAB_ID_VISIBLE`
- `CLEANUP_AGENT_TASKS`

### 시나리오
- 피싱 페이지로 현재 탭 강제 이동
- 사용자가 보고 있던 탭 닫기
- hidden tab reveal
- 작업 중인 태스크 중단
- 탭 구조 교란

### 보안 해석
- 이건 정보 조회를 넘어 사용자의 브라우저 상태를 쓰기 변경할 수 있다는 뜻이다.
- 단독으로도 UX 하이재킹/방해/리다이렉션 이슈가 되지만, 시나리오상 WA-004/WA-006보다 한 단계 낮게 평가했다.

## WA-006: hidden tab 기반 browser-driven request proxy / CSRF-like primitive

### 코드 관찰
- `GetContent`는 필요한 경우 hidden tab을 만든다.
- 이후 공격자 제공 `url`을 해당 탭에 로드하고, 렌더링이 끝날 때까지 기다린 뒤 콘텐츠를 수집한다.
- 이 경로는 일반 `fetch()`가 아니라 사용자의 실제 브라우저 세션/렌더링 엔진을 사용한다.

### 시나리오
1. 공격자 localhost 페이지가 `CALL_TOOL:GetContent`에 임의 URL 목록을 넣어 호출한다.
2. extension이 hidden tab을 생성하고 URL을 연다.
3. 사용자의 로그인 세션/브라우저 컨텍스트로 페이지가 로드된다.
4. extension이 해당 페이지의 normalized content를 수집해 공격자에게 반환한다.

### 왜 Critical인가
- 사용자의 브라우저가 내부 웹앱/로그인된 서비스/사내 페이지에 대신 요청을 보내고 콘텐츠를 회수한다.
- 단순 CSRF보다 더 강하다. 요청만 보내는 것이 아니라 결과까지 읽어 와서 외부로 넘길 수 있기 때문이다.
- 현재 PoC에서 raw HTML 전체는 확인되지 않았지만, `markdown` 중심 normalized content만으로도 유출 가치는 충분하다.

### 보안 해석
- 정확한 표현은 `browser-driven request proxy + authenticated content exfiltration`이다.
- CSRF-like 요소가 있지만, 결과 읽기까지 포함되므로 고전적 CSRF보다 범위가 더 넓다.

## XSS / CSRF 관점 짧은 메모
- direct DOM XSS:
  - 현재 저장소 기준 고신뢰로는 미확정
- HTML injection carrier:
  - `selection.html` raw fragment 전달은 여전히 위험
- page-world script sink:
  - `google_docs_web.js`의 `eval(...)`은 sink이지만 현재 exploit 미확정
- CSRF-like:
  - `WA-006`이 사실상 핵심

## 결론
- write/network 관점에서 가장 치명적인 것은 `WA-004`와 `WA-006`이다.
- `WA-005`도 충분히 위험하지만, 단독보다는 다른 유출 primitive와 결합될 때 더 위협적이다.
- 따라서 우선순위는 아래처럼 정리하는 것이 타당하다.
  1. `WA-004` 차단: 공격자 제어 `base_url` 제거
  2. `WA-006` 차단: hidden tab 기반 arbitrary content fetch 차단
  3. `WA-005` 축소: 외부 origin write primitive 최소화
