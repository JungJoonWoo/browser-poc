# XSS / CSRF 관점 코드 분석

## 요약
현재 저장소 기준으로는 "즉시 exploitable direct DOM XSS"보다 "HTML injection carrier"와 "browser-driven CSRF-like content proxy"가 더 현실적인 위험이다.

## XSS

### 직접 XSS
- `overlay.js`
  - 상태 텍스트는 `textContent`로만 갱신됨
- `events.js`
  - 입력 차단용 이벤트 처리이며 HTML sink로 이어지지 않음
- 결론
  - 현재 저장소 단독으로는 direct DOM XSS를 고신뢰로 확인하지 못함

### HTML injection carrier
- `content.js`
  - 사용자가 선택한 DOM 조각을 `a.innerHTML`로 직렬화
- 의미
  - 현재 저장소 안에서 다시 렌더링되는 sink는 못 찾았지만, downstream UI가 unsafe HTML 렌더링을 하면 XSS로 승격될 수 있음

### Script sink
- `google_docs_web.js`
  - page-world `eval(...)` 사용
- 의미
  - sink 자체는 맞지만, 현재 저장소 기준 외부 입력이 직접 흘러드는 고신뢰 exploit path는 미확정

## CSRF-like

### 고전적 CSRF보다 더 강한 부분
- `GetContent` / hidden tab 경로는 단순 요청 전송이 아니라 결과 회수까지 포함
- 따라서 "요청 위조"를 넘어서 "결과 읽기 가능한 browser-driven request proxy"에 가깝다

### 현재 고신뢰 평가
- classic CSRF:
  - 개념 일부 해당
- stronger browser-driven proxy:
  - 예, 고신뢰

## 결론
- direct XSS는 현재 저장소 단독으로는 미확정
- `selection.html` carrier와 `eval` sink는 추후 소비자 코드/입력 흐름이 추가되면 승격 가능
- CSRF 관점에서는 `WA-006`이 실제 핵심 이슈다
