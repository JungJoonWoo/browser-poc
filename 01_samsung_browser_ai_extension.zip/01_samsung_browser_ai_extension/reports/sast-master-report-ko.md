# Web-Agent Extension SAST 메인 보고서

## 1. 개요
- 대상: `C:\Users\kyuhan.lee\Desktop\취약점진단\01_samsung_browser_ai_extension`
- 범위:
  - 비즈니스 로직 분석
  - 아키텍처 문서화
  - 외부 메시지/권한 경계 점검
  - 내부 정보 유출 관점 점검
  - 웹 XSS / HTML carrier / AI prompt injection 점검
  - PoC 하네스 및 증적 문서화

## 2. 검증 방식
- 정적 코드 검증 완료
- PoC 하네스 생성 완료
- 로컬 브라우저 동적 실행은 현재 Codex 환경에서 수행하지 못함
- 따라서 아래 "확정"은 코드 경로 기준 확정이며, `poc/` 경로의 하네스로 로컬 브라우저 재현이 가능하도록 구성함
- 설치본 extension ID는 `C:\Program Files\Samsung\Internet\Application\143.0.0.95\Extensions\ai_extensions.json` 기준 `mdnblglgnmnipmchmdjhlbaaeeolmfli`로 보정함
- 저장소의 `content.js`에는 다른 ID(`klonjilicpkllfccockncpckffhnfnmo`)가 하드코딩되어 있어 패키징/소스 드리프트 가능성이 있음

## 3. 결과 요약

| ID | 심각도 | 상태 | 분류 | 요약 |
| --- | --- | --- | --- | --- |
| `WA-001` | Critical | Confirmed | 권한 경계 / 내부 정보 유출 | `localhost` 포함 외부 origin이 privileged external API를 호출해 탭/브라우저 데이터를 읽을 수 있음. 스크린샷은 legacy 경로가 더 안정적임 |
| `WA-002` | Medium-High | Conditional | 전역 상태 오염 / 내부 정보 유출 | 전역 `prompt`와 자동응답 대상 탭 상태를 읽고 쓰는 인터페이스는 존재하지만, 현재 설치본 실행에서는 상태가 세팅되지 않아 즉시 재현되지 않았음 |
| `WA-003` | Medium-High | Confirmed | AI prompt injection / 데이터 과수집 | 공격자 제어 페이지 콘텐츠와 폼 값, 숨은 텍스트, 선택 HTML이 trust demotion 없이 agent context로 전달됨 |
| `WA-004` | Critical | Confirmed | Network / Exfiltration | 외부 origin이 `START_AGENT`에 공격자 제어 `base_url`을 넣어 extension 자체가 공격자 backend와 통신하게 만들 수 있음 |
| `WA-005` | High | Confirmed | Write / Browser state manipulation | 외부 origin이 탭 열기/이동/닫기/그룹 변경/hidden tab reveal 등 브라우저 상태를 직접 바꿀 수 있음 |
| `WA-006` | Critical | Confirmed | CSRF-like / Browser-driven content proxy | `GetContent`가 hidden tab을 생성해 공격자 지정 URL을 사용자 세션으로 열고 normalized content를 수집할 수 있음 |

## 4. 상세 분석

### WA-001: `localhost` 신뢰로 인한 privileged external API 노출

#### 요약
- `manifest.json`이 `*://localhost:*/*`를 `externally_connectable`에 포함한다.
- `background.js`는 `onMessageExternal` 리스너를 두 개 운용한다.
- 첫 번째 리스너는 추가 runtime origin 검증 없이 `Ji`로 바로 진입한다.
- 두 번째 리스너도 `aa()`에서 `localhost`를 명시적으로 허용한다.
- 결과적으로 로컬 웹페이지가 확장 프로그램의 브라우저 권한 API를 호출할 수 있다.

#### 영향
- 열린 탭 목록 유출
- 현재 활성 탭 정보 유출
- 가시 탭 스크린샷 유출
- `CALL_TOOL`을 통한 고권한 툴 호출
- 현재 탭 네비게이션 변경
- 에이전트 태스크 시작/정지 간섭 가능성

#### 공격 시나리오
1. 사용자가 확장 프로그램이 설치된 브라우저에서 `http://localhost:<port>/...` 페이지를 연다.
2. 해당 페이지가 `chrome.runtime.sendMessage(extensionId, payload)`를 사용해 확장에 직접 메시지를 보낸다.
3. 확장은 origin을 신뢰하고, 탭/스크린샷/컨텍스트/툴 결과를 반환한다.
4. 페이지는 이를 서버 업로드 또는 추가 조작에 사용할 수 있다.

#### 더 정확한 시나리오 해석
- 이 취약점의 핵심은 "사용자 캡처 이벤트를 중간에서 가로채는 것"이 아니라, 악성 localhost 페이지가 확장 프로그램의 고권한 외부 API를 직접 호출할 수 있다는 점이다.
- 실제 가능한 흐름은 다음과 같다.
  - 악성 localhost 페이지가 열린 탭/현재 탭 정보를 조회한다.
  - 같은 페이지가 `S_CAPTURE_TAB`로 현재 창의 visible tab을 직접 캡처한다.
  - 또는 `CALL_TOOL`/`S_CALL_TOOL` 기반 콘텐츠 수집 메서드로 normalized content/markdown을 수집한다.
  - 수집된 결과를 공격자 서버로 전송한다.
- 특히 콘텐츠 수집 경로는 코드상 hidden tab 생성/탭 업데이트 경로를 포함하므로, 단순 "현재 화면 캡처"보다 더 강한 시나리오가 된다.
- 단, 현재 실증된 것은 raw HTML 전체가 아니라 `GetContent`가 반환하는 normalized content/markdown 경로다.

#### 근거
- `manifest.json`: `externally_connectable.matches`에 `*://localhost:*/*`
- `background.js`: `chrome.runtime.onMessageExternal.addListener((s,e,t)=>(Tt(Ji)(s,e,t),!0));`
- `background.js`: `aa()`가 `hostname === "localhost"` 허용
- `background.js`: `S_GET_OPEN_TABS`, `S_CAPTURE_TAB`, `S_GET_CURRENT_TAB_INFO`, `S_OPEN_PAGE_CURRENT_TAB`, `S_CALL_TOOL`

#### PoC
- 경로: `poc/WA-001/localhost-api-harness.html`
- 최종 exfil 경로: `poc/WA-001/exfil-demo.html`
- Cloudflare receiver: `poc/WA-001/cloudflare-worker-receiver.js`
- 증적: `evidence/WA-001/`

#### 실제 수행 결과 반영
- `S_GET_OPEN_TABS`, `S_GET_CURRENT_TAB_INFO`, `S_OPEN_PAGE_CURRENT_TAB`은 정상 동작이 확인되었다.
- `CALL_TOOL:GetVisibleTabScreenshot`는 아래 generic failure가 관찰되었다.

```json
{
  "success": false,
  "response": {
    "errorType": "unhandled",
    "errorMsg": "Unhandled error"
  }
}
```

- 반면 코드상 legacy 외부 API `S_CAPTURE_TAB`는 별도 `captureVisibleTabSnapshot` 경로를 사용한다.
- 따라서 현재 설치본에서는 스크린샷 PoC를 `CALL_TOOL:GetVisibleTabScreenshot` 단일 경로에 의존하지 않고 `S_CAPTURE_TAB`를 우선 사용하는 것이 타당하다.

#### 실패 원인 분석
- `GetVisibleTabScreenshot`는 `chrome.tabs.captureVisibleTab(...)` promise 경로를 사용한다.
- legacy `S_CAPTURE_TAB`는 `chrome.tabs.captureVisibleTabSnapshot(...)` callback 경로를 사용한다.
- 실제 Samsung Browser 설치본에서 generic failure가 발생한 것으로 보아, 현재 빌드에서는 표준 promise 경로가 브라우저/권한/서비스워커 조합상 불안정하거나 예외를 일반화해 반환하는 것으로 해석된다.
- 취약점 자체의 부정 근거는 아니며, "같은 정보 자산에 접근하는 대체 외부 API가 존재"하므로 PoC는 해당 안정 경로를 우선 사용한다.

#### 권고
- 배포 빌드에서 `localhost` 제거 또는 feature flag 분리
- 외부 메시지에 runtime token / nonce / session binding 추가
- 고권한 API는 사용자 제스처 또는 명시적 승인 후에만 허용
- 외부 origin마다 허용 메서드 allowlist 분리

### WA-002: 전역 `prompt` / 자동응답 상태의 외부 노출과 탭 오염

#### 요약
- `background.js`는 `S_SET_USER_PROMPT`를 받으면 전역 변수 `cs`에 prompt를 저장하고, `ds`에 탭 ID를 저장한다.
- 외부 origin은 `S_GET_USER_PROMPT`로 `cs`를 읽을 수 있다.
- 외부 origin은 `S_SET_AUTO_RESPONSE`로 `ds` 탭에 임의 응답을 주입할 수 있다.
- 요청자와 저장자 사이의 origin binding, tab binding, request binding이 없다.

#### 영향
- 사용자가 직전에 입력한 프롬프트 탈취
- 다른 탭/세션에 대한 자동응답 인젝션
- 사용자 의도와 무관한 워크플로우 오염
- 내부 대화/명령/민감 프롬프트 유출 가능성

#### 악용 조건
- 선행 조건: 합법 UI 또는 내부 흐름이 `S_SET_USER_PROMPT`를 먼저 호출해야 한다.
- 그러나 이 선행 조건은 정상 사용 중 자연스럽게 충족될 수 있다.

#### 근거
- `background.js`: `let cs,ds;`
- `background.js`: `s.type==="S_SET_USER_PROMPT"&&(cs=s.prompt,e.tab?.id!=null&&(ds=e.tab.id))`
- `background.js`: `S_GET_USER_PROMPT`는 `cs` 반환 후 즉시 삭제
- `background.js`: `S_SET_AUTO_RESPONSE`는 `ds` 탭에 `chrome.tabs.sendMessage(ds,{type:"S_AUTO_RESPONSE",response:s.response})`

#### PoC
- 경로: `poc/WA-002/state-hijack-harness.html`
- 증적: `evidence/WA-002/`

#### 실제 수행 결과 반영
- 실제 설치본에서 채팅 후 `S_GET_USER_PROMPT`, `S_SET_AUTO_RESPONSE` 호출 시 HTTP/IPC 레벨로는 응답이 왔다.
- 그러나 결과는 아래와 같았다.

```json
{
  "success": true,
  "response": {}
}
```

```json
{
  "success": true
}
```

- 이는 외부 인터페이스 자체는 살아 있으나, 전역 상태 `cs`와 `ds`가 현재 세션에서 채워지지 않았음을 의미한다.

#### 해석
- 현재 설치본/실사용 플로우에서는 `S_SET_USER_PROMPT`가 더 이상 호출되지 않거나, 다른 코드 경로/다른 빌드 아티팩트에서만 사용될 가능성이 있다.
- 따라서 본 finding은 "인터페이스 존재 + 상태 시드 필요"인 조건부 이슈로 재분류한다.
- 즉, 코드상 latent surface는 존재하지만 현재 관찰 세션 기준 즉시 악용이 재현되지는 않았다.
- 또한 현재 저장소 범위에서 `S_SET_AUTO_RESPONSE`는 "응답을 읽어 오는 primitive"가 아니라 저장된 탭으로 값을 주입하는 write primitive로 확인된다.
- 따라서 WA-002 단독으로 LLM 응답을 외부로 읽어 가는 시나리오는 현재 코드 기준 고신뢰로 확인되지 않았다.
- 다만 WA-001/WA-003 같은 별도 read primitive가 결합되면 화면에 표시된 질문/응답이 우회적으로 유출될 수 있다.

#### 추가 관찰
- 저장소의 `content.js`에는 설치본과 다른 extension ID가 하드코딩되어 있다.
- 이 드리프트가 실제 메시지 시드/응답 경로 일부를 깨뜨렸을 가능성은 있으나, 현재 코드만으로 직접 단정할 수는 없다.

#### 권고
- `prompt`와 자동응답 상태를 전역 변수 대신 세션 객체로 분리
- 요청자 origin, tabId, taskId를 함께 저장하고 동일 컨텍스트에서만 읽기 허용
- 읽기/쓰기 모두 one-time token 기반으로 보호
- 민감 프롬프트는 외부 origin에 직접 반환하지 말고 내부 UI에서만 소비

### WA-003: 공격자 제어 콘텐츠가 trust demotion 없이 agent context로 전달됨

#### 요약
- `content.js`는 사용자가 선택한 DOM 조각을 `cloneContents()` 후 `innerHTML`로 직렬화해 보관한다.
- `offscreen.js`는 `input`, `textarea`, `select`, `option`을 그대로 유지하고, 링크/타이틀/라벨/Google Docs 모델 데이터까지 Markdown으로 변환한다.
- `background.js`는 선택영역, 스크린샷, 페이지 Markdown을 sidecar 또는 외부 호출자에게 전달한다.
- 즉, 공격자 제어 페이지의 숨은 지시문, 폼 값, 접근성 텍스트, HTML fragment가 별도 신뢰도 표식이나 완화 없이 agent context로 유입된다.
- 이 데이터가 이후 원격 LLM/backend 서비스로 전송되면, 브라우저 내부 데이터가 외부 처리 경계 밖으로 나가므로 정보 유출로 분류할 수 있다.

#### 영향
- AI prompt injection
- hidden instruction 기반 모델 조작
- 폼 값/선택영역/페이지 일부의 외부 전송
- downstream UI가 `selection.html`을 unsafe HTML로 렌더링할 경우 XSS carrier

#### 근거
- `content.js`: `a.appendChild(h), { text: ..., html: a.innerHTML, ... }`
- `content.js`: `USER_SELECTION_CAPTURED`
- `offscreen.js`: `keep(["input","textarea","select","option"])`
- `offscreen.js`: `focusedInput` 및 `outerHTML` 유지
- `offscreen.js`: Google Docs `DOCS_modelChunk` 파싱
- `background.js`: `USER_SELECTION_CAPTURED`를 sidecar/voice/inline assistant 포트로 전달
- `background.js`: `GetSidecarContext` / `GetContent` / `GetSidecarPageContent`

#### PoC
- 경로: `poc/WA-003/prompt-injection-carrier-harness.html`
- 증적: `evidence/WA-003/`

#### 실제 수행 결과 반영
- `CALL_TOOL:GetSidecarContext`는 성공했고, 반환된 `markdown`에 아래 마커들이 포함되었다.
  - `WA003_FORM_SECRET_VALUE`
  - `WA003_TEXTAREA_SECRET`
- 반면 `WA003_VISIBLE_TEXT`, `WA003_HIDDEN_ARIA_PROMPT`, `WA003_LINK_TITLE`는 현재 설치본 최신 실행에서 hit되지 않았다.
- 따라서 현재 설치본에서 확실히 입증된 것은 "폼 입력값과 textarea 값이 agent context로 유입된다"는 점이다.

#### 가능한 공격 시나리오
- 민감정보 유출:
  - 사용자가 웹페이지 폼에 입력한 값이 agent context로 유입되고, 이후 모델 응답/원격 백엔드/툴 체인으로 전송될 수 있다.
- prompt injection:
  - 공격자가 페이지 내 입력 필드나 textarea에 지시문을 심어 모델 컨텍스트를 오염시킬 수 있다.
  - 현재 최신 실행에서는 hidden aria / link-title 계열은 hit되지 않았지만, 폼 값과 textarea 값만으로도 충분히 문맥 오염이 가능하다.
- 2차 UI 위험:
  - `selection.html`은 raw HTML fragment이므로, 이를 소비하는 downstream UI가 unsafe 렌더링을 하면 XSS carrier가 될 수 있다.

#### keylogger 관점 해석
- 현재 확인된 범위만 보면 WA-003는 "모든 키 입력 이벤트를 실시간으로 가로채는 keystroke keylogger"는 아니다.
- 이유:
  - 저장소 내에서 `input` / `beforeinput` / `change` / `submit` 이벤트를 전역적으로 탈취해 외부로 보내는 전용 코드 경로는 확인되지 않았다.
  - 현재 실증된 것은 `input` / `textarea` 값이 콘텐츠 수집 시점의 스냅샷으로 agent context에 포함된다는 점이다.
- 하지만 WA-001과 결합하면 위험도는 크게 올라간다.
  - 공격자 localhost 페이지가 5초마다 `GetContent` / `GetSidecarContext`를 반복 호출
  - 각 시점의 `input` / `textarea` 값을 Cloudflare 등 공격자 서버로 업로드
  - 결과적으로 사용자가 입력 중인 값의 변화가 주기적으로 누적 수집된다
- 따라서 보안 분류상 더 정확한 표현은 아래와 같다.
  - `실시간 keylogger`: 현재 증거 부족
  - `form-grabber`: 예, 가능
  - `polling-based pseudo-keylogger`: 예, WA-001과 결합 시 가능

#### 짧은 로그인/빠른 제출 시나리오 해석
- 사용자가 로그인 입력을 5초 미만으로 끝내고 즉시 제출하면, 5초 polling 기반 PoC는 값을 놓칠 수 있다.
- 즉, 현재 입증된 위협은 "모든 빠른 로그인 시도도 무조건 잡는다"가 아니다.
- 다만 아래 조건이면 여전히 공격 가치가 높다.
  - 사용자가 입력 필드에 값을 일정 시간 유지
  - 공격자 페이지가 polling 간격을 더 짧게 설정
  - 공격 대상이 로그인보다 긴 폼, 채팅 입력창, 검색창, 메모/문서 입력창인 경우
- 결론적으로 현재 코드는 제출 이벤트 후킹보다는 스냅샷 기반 반복 수집에 더 가깝다.

#### 권고
- 페이지 유래 콘텐츠를 "untrusted page content"로 명시적으로 라벨링
- 시스템 프롬프트와 사용자 프롬프트와 웹 콘텐츠를 구조적으로 분리
- 폼 값/숨은 텍스트/selection HTML은 기본 비활성화 또는 명시적 opt-in
- `selection.html`은 text-only 또는 sanitize 후 전달
- downstream UI가 HTML을 렌더링할 때는 sanitizer/Trusted Types 적용

## 5. 우선순위
1. `WA-001` 즉시 수정
2. `WA-002` 세션 바인딩 추가
3. `WA-003` agent content trust boundary 설계 수정

## 6. 산출물 맵
- 아키텍처: `docs/architecture-overview-ko.md`
- 인터페이스 매트릭스: `docs/external-interface-matrix-ko.md`
- 심볼 사전: `docs/symbol-glossary-ko.md`
- 미확정 후보: `reports/not-confirmed-candidates-ko.md`
- 결합 공격 체인: `reports/combined-attack-chain-ko.md`
- write/network 분석: `reports/write-network-assessment-ko.md`
- XSS/CSRF 분석: `reports/xss-csrf-assessment-ko.md`
- PoC 실행 안내: `poc/README-ko.md`

## 7. 결론
- 이 확장의 핵심 리스크는 단일 DOM sink보다 "외부 페이지에 대한 브라우저 권한 위임" 자체다.
- 특히 `localhost` 허용은 내부 정보 유출과 권한 남용을 동시에 가능하게 하므로 최우선 제거 대상이다.
- AI 기능 측면에서는 페이지 콘텐츠를 untrusted source로 취급하지 않는 현재 구조가 prompt injection과 민감 데이터 과수집 위험을 높인다.
