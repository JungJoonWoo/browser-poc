# 미확정 또는 추가 동적 검증 필요 항목

## 1. 직접 DOM XSS in overlay
- 상태: 미확정
- 이유:
  - `overlay.js`는 상태 텍스트를 `textContent`로 갱신한다.
  - 현재 저장소 범위에서 오버레이 자체가 외부 HTML을 그대로 `innerHTML`로 렌더링하는 고신뢰 sink는 확인되지 않았다.

## 2. `google_docs_web.js`의 `eval(...)`
- 상태: sink 확인, exploit 미확정
- 이유:
  - page-world `eval`은 보안적으로 좋지 않다.
  - 다만 현재 입력 문자열은 상수이고, 현재 저장소 기준으로 외부 입력이 직접 흘러드는 경로는 확인되지 않았다.
- 조치 권고:
  - `eval` 제거
  - Google Docs 호환 목적이라도 safer injection 방식 사용

## 3. `cookies` / `debugger` / `declarativeNetRequestWithHostAccess` 권한의 실제 악용 경로
- 상태: 과권한 가능성 있음, 현재 exploit 미확정
- 이유:
  - 권한 자체는 매우 강하다.
  - 현재 검토 범위에서는 외부 origin이 이 권한들을 직접 사용하는 명시 경로를 일부만 확인했다.
  - 추후 `debugger` attach / network interception / cookie access 경로를 추가 추적하면 더 큰 영향이 나올 수 있다.

## 4. `selection.html`의 downstream XSS
- 상태: carrier 확인, 실제 저장소 내 exploit 미확정
- 이유:
  - `content.js`가 HTML fragment를 직렬화해 전달하는 것은 확인됨
  - 그러나 본 저장소 안에서 그 값을 unsafe HTML로 다시 렌더링하는 소비자는 확인되지 않았다
- 의미:
  - 현재 저장소 단독으로는 "HTML injection carrier"
  - sidecar/UI 소비자 코드까지 합쳐 보면 XSS로 승격될 수 있음

## 5. `START_AGENT`의 완전한 원격 악용
- 상태: 강한 후보, 추가 동적 검증 필요
- 이유:
  - 외부 origin이 `START_AGENT`를 직접 보낼 수 있는 코드는 확인됨
  - 실제 태스크 시작 후 백엔드/소켓/overlay까지 end-to-end 성공하는지는 브라우저 동적 환경 검증이 필요함
