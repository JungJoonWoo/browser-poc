export default {
  async fetch(request, env) {
    const corsHeaders = {
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "GET,POST,OPTIONS",
      "access-control-allow-headers": "content-type,x-exfil-token"
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    if (request.method === "GET") {
      return Response.json(
        {
          ok: true,
          message: "WA-001 receiver is alive",
          hasR2Binding: Boolean(env.EXFIL_BUCKET),
          usage: {
            postJsonTo: "/collect",
            authHeader: "x-exfil-token"
          }
        },
        { headers: corsHeaders }
      );
    }

    if (request.method !== "POST") {
      return new Response("Method Not Allowed", {
        status: 405,
        headers: corsHeaders
      });
    }

    if (env.EXFIL_TOKEN) {
      const token = request.headers.get("x-exfil-token");
      if (token !== env.EXFIL_TOKEN) {
        return Response.json(
          { ok: false, error: "invalid token" },
          { status: 403, headers: corsHeaders }
        );
      }
    }

    const rawBody = await request.text();
    const parsedBody = (() => {
      try {
        return JSON.parse(rawBody);
      } catch {
        return { raw: rawBody };
      }
    })();

    const id = crypto.randomUUID();
    const timestamp = new Date().toISOString();
    const metadata = {
      id,
      timestamp,
      ip: request.headers.get("CF-Connecting-IP"),
      userAgent: request.headers.get("User-Agent"),
      colo: request.cf && request.cf.colo ? request.cf.colo : null,
      country: request.cf && request.cf.country ? request.cf.country : null,
      path: new URL(request.url).pathname,
      receivedBytes: rawBody.length
    };

    const eventObject = {
      metadata,
      body: parsedBody
    };

    if (env.EXFIL_BUCKET) {
      const key = `events/${timestamp.replace(/[:.]/g, "-")}_${id}.json`;
      await env.EXFIL_BUCKET.put(key, JSON.stringify(eventObject, null, 2), {
        httpMetadata: {
          contentType: "application/json"
        }
      });
      return Response.json(
        {
          ok: true,
          stored: true,
          storage: "r2",
          key,
          id,
          receivedBytes: rawBody.length
        },
        { headers: corsHeaders }
      );
    }

    console.log("WA-001 receiver event", JSON.stringify(eventObject));
    return Response.json(
      {
        ok: true,
        stored: false,
        storage: "console-only",
        id,
        receivedBytes: rawBody.length
      },
      { headers: corsHeaders }
    );
  }
};
