# PoC 실행 안내

## 1. 공통 전제
- 브라우저: Chromium 계열 또는 Samsung Browser
- 확장 설치: 대상 확장이 로드되어 있어야 함
- 기본 extension ID:
  - `mdnblglgnmnipmchmdjhlbaaeeolmfli`
- 실행 origin:
  - `http://localhost:<port>/...`

## 2. 로컬 서버 실행
PowerShell:

```powershell
pwsh -File .\poc\start-localhost.ps1 -Port 17777
```

기본 URL:

```text
http://localhost:17777/
```

## 3. 실행 순서

### WA-001
1. `http://localhost:17777/WA-001/localhost-api-harness.html` 접속
2. `S_GET_OPEN_TABS`, `S_GET_CURRENT_TAB_INFO` 버튼으로 정보 노출을 먼저 확인
3. 스크린샷은 `S_CAPTURE_TAB (Legacy)`를 우선 실행
4. `CALL_TOOL:GetVisibleTabScreenshot (Experimental)`과 `S_CALL_TOOL:GetVisibleTabScreenshot`로 게이트웨이별 동작 차이도 확인
5. 두 경로 모두 실패하고 `S_CAPTURE_TAB`만 성공하면, 현재 설치본에서는 legacy screenshot API가 더 안정적인 것으로 해석
6. 결과가 렌더링되면 외부 localhost 페이지에서 브라우저 데이터가 읽히는지 확인

### WA-001 최종 exfil PoC
1. Cloudflare Worker에 `poc/WA-001/cloudflare-worker-receiver.js` 배포
2. 가능하면 `poc/WA-001/wrangler.toml.example`를 참고해 `EXFIL_TOKEN`과 `EXFIL_BUCKET`을 설정
3. `http://localhost:17777/WA-001/exfil-demo.html` 접속
4. 현재 기본 Receiver URL은 `https://browser.happymon1010.workers.dev/`로 설정됨
5. 필요하면 token 입력
6. one-shot 버튼으로 단건 전송 확인
7. `Start 5s open-tab titles exfil only` 버튼은 5초마다 열린 탭 제목/URL 목록을 업로드
8. `Start 5s open-tab content/markdown exfil only` 버튼은 5초마다 `GetContent` 기반 탭 콘텐츠를 업로드
9. `Start 5s screenshot exfil only` 버튼은 5초마다 `S_CAPTURE_TAB` 결과를 업로드
10. continuous loop를 켜면 선택한 API를 주기적으로 호출해 계속 전송
11. 즉, 기본은 1회 전송이고, 반복 전송은 공격자 페이지가 loop 로직을 명시적으로 돌릴 때만 발생

### WA-002
1. 정상 삼성 웹앱 또는 확장 흐름에서 `S_SET_USER_PROMPT`가 먼저 발생한 상태를 만든다
2. `http://localhost:17777/WA-002/state-hijack-harness.html` 접속
3. `S_GET_USER_PROMPT` 실행 후 저장된 prompt 유출 여부 확인
4. 응답이 `{}`이면 현재 세션에서 `cs`가 시드되지 않은 상태로 해석
5. `S_SET_AUTO_RESPONSE`는 인터페이스 접근성 확인용으로 사용하되, 현재 세션에 `ds`가 없으면 효과가 없을 수 있음
6. 현재 설치본 기준으로는 위 4번 결과가 반복되면 즉시 exploit이 아니라 latent/conditional surface로 판단

### WA-003
1. `http://localhost:17777/WA-003/prompt-injection-carrier-harness.html` 접속
2. 페이지 하단의 marker 요소가 로드된 상태에서 `CALL_TOOL:GetSidecarContext` 실행
3. 반환된 markdown/json과 `Marker Check` 영역에 `WA003_*` marker가 포함되는지 확인

### WA-004
1. Cloudflare Worker에 `poc/WA-004/cloudflare-agent-endpoint.js` 배포
2. 필요하면 `poc/WA-004/wrangler.toml.example`를 참고해 `WA004_TOKEN`과 `WA004_BUCKET` 설정
3. `http://localhost:17777/WA-004/start-agent-backend-hijack.html` 접속
4. `base_url`에는 Worker origin만 입력
  예: `https://your-worker.workers.dev`
5. `Send START_AGENT` 클릭
6. 성공 기준:
  - localhost 페이지가 응답을 받는 것보다
  - Worker가 `/agent` 요청을 `origin: chrome-extension://mdnblglgnmnipmchmdjhlbaaeeolmfli`로 직접 수신하는 것
7. 더 강한 성공 기준:
  - Worker에 `ws-upgrade`, `ws-message`, `ws-close` 이벤트가 기록되는 것
  - 특히 채팅/후속 agent 동작 이후 `ws-message`가 추가되면 해당 세션 데이터가 attacker backend까지 도달했음을 강하게 시사
8. 이 PoC는 프로토콜 완전 에뮬레이션보다 "extension이 attacker backend와 직접 붙고 후속 프레임을 보냈다"는 증명에 초점을 둔다

## 4. 실패 시 체크포인트
- `chrome.runtime.sendMessage`가 없다면:
  - 브라우저가 해당 API를 외부 페이지에 노출하지 않았거나
  - extension ID가 다르거나
  - 현재 origin이 `externally_connectable`에 매치되지 않을 수 있음
- extension ID 입력칸에 다른 값을 넣어 재시도 가능
- 참고:
  - 설치본 기준 ID는 `ai_extensions.json`에서 `mdnblglgnmnipmchmdjhlbaaeeolmfli`로 확인했다.
  - 저장소의 `content.js`에는 다른 ID(`klonjilicpkllfccockncpckffhnfnmo`)가 하드코딩되어 있어 소스/패키징 드리프트 가능성이 있다.

## 5. 안전 메모
- WA-001의 탭 이동 버튼은 브라우저 상태를 바꾸므로 기본적으로 클릭하지 않는 것을 권장
- WA-002는 선행 상태가 필요한 PoC다. 빈 응답은 인터페이스 부재가 아니라 "state not seeded"일 수 있다
- WA-003는 malicious content extraction을 보여 주기 위한 페이지이며, 실제 downstream UI의 XSS까지는 포함하지 않는다
- 현재 설치본에서 실제로 동작하는 screenshot 경로는 `S_CAPTURE_TAB`이며, 이 경로는 브라우저 UI/picker를 노출할 수 있다
- 현재 externally reachable surface에서 그 picker를 끄거나 항상 전체 화면으로 강제하는 옵션은 확인되지 않았다
- 현재 WA-001 PoC의 `GetContent` 경로는 raw HTML 전체가 아니라 `markdown` 중심 normalized content를 주로 반환한다
