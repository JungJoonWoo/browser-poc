param(
    [int]$Port = 17777
)

$root = Split-Path -Parent $PSCommandPath
$prefix = "http://localhost:$Port/"
$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add($prefix)
$listener.Start()

Write-Host "Serving PoC files from $root"
Write-Host "Open $prefix in a Chromium-based browser. Press Ctrl+C to stop."

$contentTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".txt"  = "text/plain; charset=utf-8"
    ".md"   = "text/markdown; charset=utf-8"
    ".png"  = "image/png"
}

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        $relative = $request.Url.AbsolutePath.TrimStart("/")
        if ([string]::IsNullOrWhiteSpace($relative)) {
            $relative = "README-ko.md"
        }

        $candidate = Join-Path $root $relative
        if ((Test-Path $candidate) -and (Get-Item $candidate).PSIsContainer) {
            $candidate = Join-Path $candidate "index.html"
        }

        if (-not (Test-Path $candidate)) {
            $bytes = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found: $relative")
            $response.StatusCode = 404
            $response.ContentType = "text/plain; charset=utf-8"
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
            continue
        }

        $extension = [System.IO.Path]::GetExtension($candidate).ToLowerInvariant()
        $response.ContentType = $contentTypes[$extension]
        if (-not $response.ContentType) {
            $response.ContentType = "application/octet-stream"
        }

        $buffer = [System.IO.File]::ReadAllBytes($candidate)
        $response.ContentLength64 = $buffer.Length
        $response.OutputStream.Write($buffer, 0, $buffer.Length)
        $response.Close()
    }
}
finally {
    $listener.Stop()
    $listener.Close()
}
