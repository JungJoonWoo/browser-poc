function corsHeaders() {
  return {
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,OPTIONS",
    "access-control-allow-headers": "content-type,authorization,x-exfil-token"
  };
}

async function persistEvent(env, key, data) {
  if (!env.WA004_BUCKET) {
    console.log("WA-004 event", JSON.stringify(data));
    return { stored: false, storage: "console-only" };
  }

  await env.WA004_BUCKET.put(key, JSON.stringify(data, null, 2), {
    httpMetadata: { contentType: "application/json" }
  });
  return { stored: true, storage: "r2", key };
}

async function logEvent(env, label, payload) {
  const timestamp = new Date().toISOString();
  const key = `wa-004/${timestamp.replace(/[:.]/g, "-")}_${crypto.randomUUID()}_${label}.json`;
  return persistEvent(env, key, { label, timestamp, payload });
}

async function handleWebSocket(request, env) {
  const pair = new WebSocketPair();
  const client = pair[0];
  const server = pair[1];

  server.accept();

  const requestMeta = {
    timestamp: new Date().toISOString(),
    method: request.method,
    path: new URL(request.url).pathname,
    headers: Object.fromEntries(request.headers.entries()),
    ip: request.headers.get("CF-Connecting-IP"),
    userAgent: request.headers.get("User-Agent"),
    origin: request.headers.get("origin")
  };

  await logEvent(env, "ws-upgrade", requestMeta);

  server.addEventListener("message", async (event) => {
    const data =
      typeof event.data === "string"
        ? event.data
        : Array.from(new Uint8Array(event.data));

    await logEvent(env, "ws-message", {
      requestMeta,
      data
    });

    // Keep the connection alive and acknowledge receipt so we can observe
    // follow-up frames from the extension if it sends any.
    try {
      server.send(
        JSON.stringify({
          type: "wa-004-observer-ack",
          observed: true,
          at: new Date().toISOString()
        })
      );
    } catch {}
  });

  server.addEventListener("close", async (event) => {
    await logEvent(env, "ws-close", {
      requestMeta,
      code: event.code,
      reason: event.reason,
      wasClean: event.wasClean
    });
  });

  server.addEventListener("error", async (event) => {
    await logEvent(env, "ws-error", {
      requestMeta,
      message: String(event.message || event.error || "unknown websocket error")
    });
  });

  return new Response(null, {
    status: 101,
    webSocket: client
  });
}

export default {
  async fetch(request, env) {
    const headers = corsHeaders();

    if (request.method === "OPTIONS") {
      return new Response(null, { headers });
    }

    if (env.WA004_TOKEN) {
      const token = request.headers.get("x-exfil-token") || request.headers.get("authorization");
      if (token && token !== env.WA004_TOKEN && token !== `Bearer ${env.WA004_TOKEN}`) {
        return Response.json({ ok: false, error: "invalid token" }, { status: 403, headers });
      }
    }

    const url = new URL(request.url);
    const upgrade = (request.headers.get("upgrade") || "").toLowerCase();

    if (upgrade === "websocket") {
      return handleWebSocket(request, env);
    }

    const rawBody = request.method === "GET" ? "" : await request.text();
    const parsedBody = (() => {
      try {
        return rawBody ? JSON.parse(rawBody) : null;
      } catch {
        return rawBody || null;
      }
    })();

    const event = {
      timestamp: new Date().toISOString(),
      method: request.method,
      path: url.pathname,
      query: Object.fromEntries(url.searchParams.entries()),
      headers: Object.fromEntries(request.headers.entries()),
      body: parsedBody,
      ip: request.headers.get("CF-Connecting-IP"),
      userAgent: request.headers.get("User-Agent"),
      colo: request.cf && request.cf.colo ? request.cf.colo : null
    };

    const key = `wa-004/${event.timestamp.replace(/[:.]/g, "-")}_${crypto.randomUUID()}_http.json`;
    const storage = await persistEvent(env, key, event);

    if (request.method === "GET") {
      return Response.json(
        {
          ok: true,
          message: "WA-004 receiver is alive",
          note: "If the extension upgrades to websocket at /agent, the worker will log ws-upgrade/ws-message/ws-close events.",
          storage
        },
        { headers }
      );
    }

    return Response.json({ ok: true, storage }, { headers });
  }
};
